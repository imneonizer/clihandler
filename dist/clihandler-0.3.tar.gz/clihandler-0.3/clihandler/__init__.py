from clihandler.clihandler import CliHandler

cli = CliHandler()

call = cli.call
get = cli.get
capture = cli.capture
kill = cli.kill
return_code = cli.return_code
reset = cli.reset
list_process = cli.list_process
__version__ = '0.3'
