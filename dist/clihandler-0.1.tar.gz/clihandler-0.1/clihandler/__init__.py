from clihandler.clihandler import CliHandler

cli = CliHandler()

call = cli.call
get = cli.get
capture = cli.capture
kill = cli.kill
list_process = cli.list_process
__version__ = '0.1.1'
